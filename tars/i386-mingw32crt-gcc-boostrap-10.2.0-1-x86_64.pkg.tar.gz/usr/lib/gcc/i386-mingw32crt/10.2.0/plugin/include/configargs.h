/* Generated automatically. */
static const char configuration_arguments[] = "/mingwcrt/mingw-gcc-bootstrap/src/gcc-10.2.0/configure --prefix=/usr --target=i386-mingw32crt --enable-languages=c,lto --enable-static --disable-nls --with-system-zlib --enable-lto --enable-threads=win32 --disable-nls --enable-version-specific-runtime-libs --disable-multilib --enable-checking=release --disable-sjlj-exceptions --with-dwarf2 --enable-libgomp=no --disable-tls : (reconfigured) /mingwcrt/mingw-gcc-bootstrap/src/gcc-10.2.0/configure --prefix=/usr --target=i386-mingw32crt --enable-languages=c,lto --enable-static --disable-nls --with-system-zlib --enable-lto --enable-threads=win32 --disable-nls --enable-version-specific-runtime-libs --disable-multilib --enable-checking=release --disable-sjlj-exceptions --with-dwarf2 --enable-libgomp=no --disable-tls";
static const char thread_model[] = "win32";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "i386" }, { "arch", "i386" } };
